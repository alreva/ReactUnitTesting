// ------------------------------------
// Constants
// ------------------------------------
export const COUNTER_INCREMENT = 'COUNTER_INCREMENT'
export const COUNTER_DOUBLE_ASYNC = 'COUNTER_DOUBLE_ASYNC'


// ------------------------------------
// Action Handlers
// ------------------------------------
const ACTION_HANDLERS = {
  [COUNTER_INCREMENT]    : (state, action) => [ "Item 2" ],
  [COUNTER_DOUBLE_ASYNC] : (state, action) => [ "Item 3" ]
}

// ------------------------------------
// Reducer
// ------------------------------------
export default function imagesReducer (state = [ "Item 1" ], action) {
  const handler = ACTION_HANDLERS[action.type]
  console.log('Images reducer executing...')
  console.log(state)
  return handler ? handler(state, action) : state
}