import { injectReducer } from '../../store/reducers'

export default (store) => ({
  path : 'images',

  getComponent (nextState, cb) {

    require.ensure([], (require) => {

      const Images = require('./containers/ImagesContainer').default
      const reducer = require('./modules/images').default

      injectReducer(store, { key: 'images', reducer })

      cb(null, Images)

    }, 'images')
  }
})