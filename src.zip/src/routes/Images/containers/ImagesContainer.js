import { connect } from 'react-redux'
//import { increment, doubleAsync } from '../modules/images'

import Images from '../components/Images'

const mapDispatchToProps = {
  increment : () => {},
  doubleAsync: () => {}
}

const mapStateToProps = (state) => ({
  items : [ "Item 5" ]
})

export default connect(mapStateToProps, mapDispatchToProps)(Images)