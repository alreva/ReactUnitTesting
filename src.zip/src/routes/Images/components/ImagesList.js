import React from 'react'
import PropTypes from 'prop-types'

export const ImagesList = ({ items }) => (
  <ul>
    <li>Here we will have our images later on...</li>
  </ul>
)

ImagesList.propTypes = {
    items: PropTypes.array.isRequired
}

export default ImagesList