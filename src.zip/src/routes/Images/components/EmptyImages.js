import React from 'react'
import PropTypes from 'prop-types'

export const EmptyImages = () => (
  <h3>No Images.</h3>
)

export default EmptyImages